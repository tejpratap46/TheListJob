<?php

require_once dirname(dirname(__FILE__)) . '/autoloader.php';
